﻿namespace library
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.yayıncıLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yayıneviListeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excelAktarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pDFAktarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çıkışToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel4 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.No = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kitap_ad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.yazar_ad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.yazarevi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kitap_kod = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.kitap_tür = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.kodcheck = new System.Windows.Forms.CheckBox();
            this.evcheck = new System.Windows.Forms.CheckBox();
            this.yazarcheck = new System.Windows.Forms.CheckBox();
            this.kitapcheck = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.eklemeyap = new System.Windows.Forms.GroupBox();
            this.yenikitapad = new System.Windows.Forms.TextBox();
            this.yeniyazarad = new System.Windows.Forms.TextBox();
            this.yenikitapevi = new System.Windows.Forms.TextBox();
            this.yenikod = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.yenitürbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.eklemeyap.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBox1,
            this.yayıncıLToolStripMenuItem,
            this.yayıneviListeToolStripMenuItem,
            this.excelAktarToolStripMenuItem,
            this.pDFAktarToolStripMenuItem,
            this.çıkışToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(840, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 23);
            this.toolStripTextBox1.Text = "Dosya";
            // 
            // yayıncıLToolStripMenuItem
            // 
            this.yayıncıLToolStripMenuItem.Name = "yayıncıLToolStripMenuItem";
            this.yayıncıLToolStripMenuItem.Size = new System.Drawing.Size(83, 23);
            this.yayıncıLToolStripMenuItem.Text = "Yayıncı Liste";
            // 
            // yayıneviListeToolStripMenuItem
            // 
            this.yayıneviListeToolStripMenuItem.Name = "yayıneviListeToolStripMenuItem";
            this.yayıneviListeToolStripMenuItem.Size = new System.Drawing.Size(89, 23);
            this.yayıneviListeToolStripMenuItem.Text = "Yayınevi Liste";
            // 
            // excelAktarToolStripMenuItem
            // 
            this.excelAktarToolStripMenuItem.Name = "excelAktarToolStripMenuItem";
            this.excelAktarToolStripMenuItem.Size = new System.Drawing.Size(75, 23);
            this.excelAktarToolStripMenuItem.Text = "Excel aktar";
            // 
            // pDFAktarToolStripMenuItem
            // 
            this.pDFAktarToolStripMenuItem.Name = "pDFAktarToolStripMenuItem";
            this.pDFAktarToolStripMenuItem.Size = new System.Drawing.Size(69, 23);
            this.pDFAktarToolStripMenuItem.Text = "PDF aktar";
            // 
            // çıkışToolStripMenuItem
            // 
            this.çıkışToolStripMenuItem.Name = "çıkışToolStripMenuItem";
            this.çıkışToolStripMenuItem.Size = new System.Drawing.Size(44, 23);
            this.çıkışToolStripMenuItem.Text = "Çıkış";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.listView1);
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Controls.Add(this.kodcheck);
            this.panel4.Controls.Add(this.evcheck);
            this.panel4.Controls.Add(this.yazarcheck);
            this.panel4.Controls.Add(this.kitapcheck);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Location = new System.Drawing.Point(216, 163);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(624, 254);
            this.panel4.TabIndex = 3;
            // 
            // listView1
            // 
            this.listView1.AllowColumnReorder = true;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.No,
            this.kitap_ad,
            this.yazar_ad,
            this.yazarevi,
            this.kitap_kod,
            this.kitap_tür});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(9, 32);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(584, 219);
            this.listView1.TabIndex = 13;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // No
            // 
            this.No.Text = "No";
            this.No.Width = 93;
            // 
            // kitap_ad
            // 
            this.kitap_ad.Text = "Kitap Adı";
            this.kitap_ad.Width = 174;
            // 
            // yazar_ad
            // 
            this.yazar_ad.Text = "Yazar Adı";
            this.yazar_ad.Width = 138;
            // 
            // yazarevi
            // 
            this.yazarevi.Text = "Kitapevi";
            this.yazarevi.Width = 97;
            // 
            // kitap_kod
            // 
            this.kitap_kod.Text = "Kitap Kodu";
            this.kitap_kod.Width = 75;
            // 
            // kitap_tür
            // 
            this.kitap_tür.Text = "Kitap Tür";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(438, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(145, 20);
            this.textBox1.TabIndex = 12;
            // 
            // kodcheck
            // 
            this.kodcheck.AutoSize = true;
            this.kodcheck.Location = new System.Drawing.Point(369, 9);
            this.kodcheck.Name = "kodcheck";
            this.kodcheck.Size = new System.Drawing.Size(63, 17);
            this.kodcheck.TabIndex = 11;
            this.kodcheck.Text = "Kod ara";
            this.kodcheck.UseVisualStyleBackColor = true;
            this.kodcheck.CheckedChanged += new System.EventHandler(this.kodcheck_CheckedChanged);
            this.kodcheck.ChangeUICues += new System.Windows.Forms.UICuesEventHandler(this.kodcheck_ChangeUICues);
            // 
            // evcheck
            // 
            this.evcheck.AutoSize = true;
            this.evcheck.Location = new System.Drawing.Point(279, 7);
            this.evcheck.Name = "evcheck";
            this.evcheck.Size = new System.Drawing.Size(84, 17);
            this.evcheck.TabIndex = 10;
            this.evcheck.Text = "Yayınevi ara";
            this.evcheck.UseVisualStyleBackColor = true;
            this.evcheck.CheckedChanged += new System.EventHandler(this.evcheck_CheckedChanged);
            // 
            // yazarcheck
            // 
            this.yazarcheck.AutoSize = true;
            this.yazarcheck.Location = new System.Drawing.Point(202, 7);
            this.yazarcheck.Name = "yazarcheck";
            this.yazarcheck.Size = new System.Drawing.Size(71, 17);
            this.yazarcheck.TabIndex = 9;
            this.yazarcheck.Text = "Yazar ara";
            this.yazarcheck.UseVisualStyleBackColor = true;
            this.yazarcheck.CheckedChanged += new System.EventHandler(this.yazarcheck_CheckedChanged);
            // 
            // kitapcheck
            // 
            this.kitapcheck.AutoSize = true;
            this.kitapcheck.Checked = true;
            this.kitapcheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.kitapcheck.Location = new System.Drawing.Point(127, 7);
            this.kitapcheck.Name = "kitapcheck";
            this.kitapcheck.Size = new System.Drawing.Size(69, 17);
            this.kitapcheck.TabIndex = 8;
            this.kitapcheck.Text = "Kitap Ara";
            this.kitapcheck.UseVisualStyleBackColor = true;
            this.kitapcheck.CheckedChanged += new System.EventHandler(this.kitapcheck_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(12, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Kitap Listesi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(6, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 15);
            this.label4.TabIndex = 14;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Location = new System.Drawing.Point(216, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(306, 100);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Yeni Kayıt";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(9, 21);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(274, 65);
            this.button6.TabIndex = 19;
            this.button6.Text = "Kitap Ekle";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.toolStrip1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(10, 41);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 413);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.toolStrip1.Location = new System.Drawing.Point(3, 16);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 5, 5, 0);
            this.toolStrip1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStrip1.Size = new System.Drawing.Size(194, 122);
            this.toolStrip1.TabIndex = 13;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripButton1.Image = global::library.Properties.Resources.world_wide_web;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(188, 20);
            this.toolStripButton1.Text = "Genel";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(188, 20);
            this.toolStripButton2.Text = "Klasik";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = global::library.Properties.Resources.group;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(188, 20);
            this.toolStripButton3.Text = "Çocuk";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = global::library.Properties.Resources.networking;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(188, 20);
            this.toolStripButton4.Text = "Bilimkurgu";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = global::library.Properties.Resources.open_book;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(188, 20);
            this.toolStripButton5.Text = "Tarih";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(27, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Kategoriler";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button10);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(539, 41);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(270, 100);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bilgilendirme";
            // 
            // button10
            // 
            this.button10.Enabled = false;
            this.button10.Location = new System.Drawing.Point(144, 27);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(109, 65);
            this.button10.TabIndex = 22;
            this.button10.Text = "Silinen Kitap";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Enabled = false;
            this.button9.Location = new System.Drawing.Point(13, 29);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(125, 65);
            this.button9.TabIndex = 21;
            this.button9.Text = "Toplam kitap:";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(589, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "ara";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(89, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(32, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "♲";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // eklemeyap
            // 
            this.eklemeyap.Controls.Add(this.label8);
            this.eklemeyap.Controls.Add(this.yenitürbox);
            this.eklemeyap.Controls.Add(this.button4);
            this.eklemeyap.Controls.Add(this.button3);
            this.eklemeyap.Controls.Add(this.label7);
            this.eklemeyap.Controls.Add(this.label6);
            this.eklemeyap.Controls.Add(this.label5);
            this.eklemeyap.Controls.Add(this.label3);
            this.eklemeyap.Controls.Add(this.yenikod);
            this.eklemeyap.Controls.Add(this.yenikitapevi);
            this.eklemeyap.Controls.Add(this.yeniyazarad);
            this.eklemeyap.Controls.Add(this.yenikitapad);
            this.eklemeyap.Location = new System.Drawing.Point(305, 147);
            this.eklemeyap.Name = "eklemeyap";
            this.eklemeyap.Size = new System.Drawing.Size(200, 211);
            this.eklemeyap.TabIndex = 17;
            this.eklemeyap.TabStop = false;
            this.eklemeyap.Text = "ekleme";
            this.eklemeyap.Visible = false;
            // 
            // yenikitapad
            // 
            this.yenikitapad.Location = new System.Drawing.Point(94, 38);
            this.yenikitapad.Name = "yenikitapad";
            this.yenikitapad.Size = new System.Drawing.Size(100, 20);
            this.yenikitapad.TabIndex = 0;
            // 
            // yeniyazarad
            // 
            this.yeniyazarad.Location = new System.Drawing.Point(94, 64);
            this.yeniyazarad.Name = "yeniyazarad";
            this.yeniyazarad.Size = new System.Drawing.Size(100, 20);
            this.yeniyazarad.TabIndex = 1;
            // 
            // yenikitapevi
            // 
            this.yenikitapevi.Location = new System.Drawing.Point(94, 90);
            this.yenikitapevi.Name = "yenikitapevi";
            this.yenikitapevi.Size = new System.Drawing.Size(100, 20);
            this.yenikitapevi.TabIndex = 2;
            // 
            // yenikod
            // 
            this.yenikod.Location = new System.Drawing.Point(94, 116);
            this.yenikod.Name = "yenikod";
            this.yenikod.Size = new System.Drawing.Size(100, 20);
            this.yenikod.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Kitap Adı";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "yazar adı";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 93);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "kitapevi";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "kod";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(94, 163);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 8;
            this.button3.Text = "Ekle";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(152, 9);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(32, 23);
            this.button4.TabIndex = 16;
            this.button4.Text = "X";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // yenitürbox
            // 
            this.yenitürbox.Location = new System.Drawing.Point(94, 142);
            this.yenitürbox.Name = "yenitürbox";
            this.yenitürbox.Size = new System.Drawing.Size(100, 20);
            this.yenitürbox.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(48, 145);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "tür";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 429);
            this.Controls.Add(this.eklemeyap);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.eklemeyap.ResumeLayout(false);
            this.eklemeyap.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripMenuItem yayıncıLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yayıneviListeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excelAktarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pDFAktarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çıkışToolStripMenuItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckBox kodcheck;
        private System.Windows.Forms.CheckBox evcheck;
        private System.Windows.Forms.CheckBox yazarcheck;
        private System.Windows.Forms.CheckBox kitapcheck;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.ColumnHeader No;
        private System.Windows.Forms.ColumnHeader kitap_ad;
        private System.Windows.Forms.ColumnHeader yazar_ad;
        private System.Windows.Forms.ColumnHeader yazarevi;
        private System.Windows.Forms.ColumnHeader kitap_kod;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ColumnHeader kitap_tür;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox eklemeyap;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox yenikod;
        private System.Windows.Forms.TextBox yenikitapevi;
        private System.Windows.Forms.TextBox yeniyazarad;
        private System.Windows.Forms.TextBox yenikitapad;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox yenitürbox;
    }
}

